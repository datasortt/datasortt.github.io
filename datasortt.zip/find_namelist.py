import sys
sys.stdout = open('script_export.txt', 'w')

def search_string_in_file(file_name, string_to_search):
#     Search for the given string in file and return lines containing that string,
#     along with line numbers
    line_number = 0
    list_of_results = []
    # Open the file in read only mode

    with open(file_name, 'r', errors= 'ignore') as read_obj:
        # Read all lines in the file one by one
        for line in read_obj:
            # For each line, check if line contains the string
            line_number += 1
            if string_to_search in line:
                # If yes, then add the line number & line as a tuple in the list
                list_of_results.append((line_number, line.rstrip()))

    # Return list of tuples containing line numbers and lines where string is found
    return list_of_results



# with open('nm.txt', 'rt', errors='replace') as f:
#     for line2 in f:
#         str(line2)
#         name = line2.rstrip(line2[-1])
#         # print(name)
#         linest = "'" + name + "'"
#         # print(linest)
#         result = search_string_in_file('Greece.txt', name)

# result = search_string_in_file("Greece.txt", 'Dimitri')


with open('names.txt', 'rt', errors= 'ignore') as nm:
    data = nm.readlines()


newtest = [x[:-1] for x in data]



for name in newtest:
    # print(name)
    result = search_string_in_file('Germany.txt', name)
    print(result)